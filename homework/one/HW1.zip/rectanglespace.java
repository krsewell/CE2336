/*
 *   HW1/rectanglespace.java
 *   Copyright 2018, Kristopher Sewell, All rights reserved.
 *
 *   Course:  CE2336  Section:  002   Project: HW1
 */

 /*
  * Write a program that prompts the user to enter the center coordinates
  * (x and y), width, and height of two rectangles and determines whether the
  * second rectangle is inside the first or overlaps with the first.
  */

public class rectanglespace {
  public static void main(String[] args) {
    
  }
}
